package com.abhii;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class PostDb 
{
	public static void postUpload(Post post1)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/user","root","");
			
			PreparedStatement st = con.prepareStatement("insert into posts(post) values(?)");
			st.setString(1, post1.getPost());
			//st.setInt(2, post1.getLike());
			//st.setInt(3, post1.getDisLike());
			//st.setInt(4, post1.getUserid());
			
			st.executeUpdate();
			return;
		}
	catch(Exception e) {}
	}
}
