package com.abhii;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class RegisterDao 
{
    public static void registerUser(User user)
    {
    	try
    		{
    			Class.forName("com.mysql.jdbc.Driver");
    			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/user","root","");
    			
    			PreparedStatement st = con.prepareStatement("insert into userinfo(username,email,password,mobile) values(?,?,?,?)");
    			st.setString(1, user.getUsername());
    			st.setString(2, user.getEmail());
    			st.setString(3, user.getPassword());
    			st.setString(4, user.getMobile());
    			
    			st.executeUpdate();
    			return;
    		}
    	catch(Exception e) {}
    }
}
