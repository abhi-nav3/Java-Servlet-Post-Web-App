package com.abhii;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Authentication 
{
	public static boolean validateUserDB()
	{
		return false;
	}
	
	public static boolean validateUser(String username, String password) 
	{
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/user","root","");
		PreparedStatement st = con.prepareStatement("select * from userinfo where username=? and password=?");
		
		st.setString(1,username);
        st.setString(2,password);
        
        ResultSet rs = st.executeQuery();
        
        if(rs.next())
        {
        	return true; 
        }
		}
		catch(Exception e) {}
		
		return false;
	}
}
