package com.abhii;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/post-servlet")
public class PostServlet extends HttpServlet {
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try
		{
			String post = request.getParameter("post");
			//int like = Integer.parseInt(request.getParameter("like"));
			//int dislike = Integer.parseInt(request.getParameter("dislike"));
			//int userid = Integer.parseInt(request.getParameter("userid"));
			
			Post post1 = new Post();
			//post1.setId(id);
			post1.setPost(post);
			
			//post1.setLike(like);
			
			//post1.setDisLike(dislike);
			
			//post1.setUserid(userid);
			
			PostDb.postUpload(post1);
			
			RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
			rd.forward(request, response);
			//response.sendRedirect("home.jsp");
		}
		catch(Exception e) {}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
