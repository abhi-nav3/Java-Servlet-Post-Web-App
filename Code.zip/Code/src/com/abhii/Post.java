package com.abhii;

public class Post 
{
	public int id;
	public String post;
	public int like; 
	public int dislike;
	public int userid;

	public int getId() {	
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	public String getPost() {
		return post;
	}
	public void setPost(String post) {
		this.post = post;
	}
	public int getLike() {
		return like;
	}
	public void setLike(int like) {
		this.like = like;
	}
	public int getDisLike() {
		return dislike;
	}
	public void setDisLike(int dislike) {
		this.dislike = dislike;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
}
