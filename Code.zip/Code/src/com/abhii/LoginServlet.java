package com.abhii;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/login-servlet")
public class LoginServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		
		try
		{
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			
			boolean auth = Authentication.validateUser(username,password);
		    if(auth)
		    {
		    	session.setAttribute("AUTH", true);
		    	
		    	RequestDispatcher rd = request.getRequestDispatcher("/home-servlet");
		    	rd.forward(request, response);
		    	//response.sendRedirect("home.jsp");
		    }
		    else
		    {
		    	session.setAttribute("ERROR","AUTHENTICATION FAILED!!!...CHECK THE CREDENTIALS.");
		    		                 	
		    	response.sendRedirect("login.jsp");
		    }
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		

	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
