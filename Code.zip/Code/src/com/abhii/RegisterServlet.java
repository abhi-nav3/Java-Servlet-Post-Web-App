package com.abhii;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.catalina.Session;


@WebServlet("/register-servlet")
public class RegisterServlet extends HttpServlet 
{
	
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session = request.getSession();
		
		try
		{
	//----------READING I/P from USER-----------	
		String username = request.getParameter("username");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String mobile = request.getParameter("mobile");
	    
	//----------PREPARE INSTANCE of USER----------
		User user = new User();
		user.setUsername(username);
		user.setEmail(email);
		user.setPassword(password);
		user.setMobile(mobile);
		
		RegisterDao.registerUser(user);
	
	//----------DB CALL----------	
		response.sendRedirect("Thanku.jsp");
		}
		catch(Exception e) 
		{
		    e.printStackTrace();
		  
		    session.setAttribute("ERROR","USER already EXISTS");    
			response.sendRedirect("Register..jsp");
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		doGet(request, response);
	}

}
